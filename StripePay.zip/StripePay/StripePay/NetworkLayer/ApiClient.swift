//
//  ApiClient.swift
//  StripePay
//
//  Created by Hamza Mustafa on 18/11/2021.
//

import Foundation
import Alamofire
import Stripe

class ApiClient: NSObject, STPCustomerEphemeralKeyProvider {
    
    func createCustomerKey(withAPIVersion apiVersion: String, completion: @escaping STPJSONResponseCompletionBlock) {
        let params = ["api_version": apiVersion]

        AF.request(URL(string: "http://10.1.30.36:8888/StripeBackend/empheralkey.php")!, method: .post, parameters: params, encoding: URLEncoding.default, headers: [:]).responseJSON { (response) in
            let data = response.data
            switch response.result {
               case .success(let value):
                debugPrint(value)
                guard let json = ((try? JSONSerialization.jsonObject(with: data!, options: []) as? [String : Any]) as [String : Any]??) else {
                    completion(nil, response.error)
                    return
                }
                completion(json,nil)

               case .failure(let error):
                debugPrint(error)
                completion(nil,response.error!)
            }
        }
    }
        
    class func createCustomer() {
        var customerDetailParams = [String:String]()
        customerDetailParams["email"] = "hamza@gmail.com"
        customerDetailParams["phone"] = "03460139780"
        customerDetailParams["name"] = "Hamza Mustafa"
        
        let url = "http://10.1.30.36:8888/StripeBackend/createCustomer.php"
        
        AF.request(url, method: .post, parameters: customerDetailParams, encoding: URLEncoding.default, headers: nil).responseJSON { (response) in
            switch response.result {
               case .success(let value):
                debugPrint(value)
               case .failure(let error):
                debugPrint(error)
            }
        }
    }
    
    class func createPaymentIntent(amount:Double,currency:String,customerId:String,completion:@escaping (Result<String, Error>)->Void){
        
        let url = "http://10.1.30.36:8888/StripeBackend/createpaymentintent.php"
        
        AF.request(URL(string: url)!, method: .post, parameters: ["amount":amount,"currency":currency,"customerId":customerId], encoding: URLEncoding.default, headers: nil).responseJSON { (response) in
            
            let data = response.data
            switch response.result {
               case .success(let value):
                debugPrint(value)
                guard let json = ((try? JSONSerialization.jsonObject(with: data!, options: []) as? [String : String]) as [String : String]??) else {
                    completion(.failure(response.error!))
                    return
                }
                completion(.success(json!["clientSecret"]!))
                
               case .failure(let error):
                debugPrint(error)
                completion(.failure(response.error!))
            }
        }
    }
}
