//
//  ViewController.swift
//  StripePay
//
//  Created by Hamza Mustafa on 18/11/2021.
//

import UIKit
import Stripe
import PassKit // use for apple pay

class ViewController: UIViewController {
    
    var customerContext: STPCustomerContext?
    var paymentContext: STPPaymentContext?
    var isSetShipping = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupMerchantShippingConfig()
    }
    
    func setupMerchantShippingConfig(){
        let config = STPPaymentConfiguration.shared
        config.applePayEnabled = true
        config.shippingType = .shipping
        config.requiredShippingAddressFields = Set<STPContactField>(arrayLiteral: STPContactField.name,STPContactField.emailAddress,STPContactField.phoneNumber,STPContactField.postalAddress)
        config.companyName = "Testing XYZ"
        customerContext = STPCustomerContext(keyProvider: ApiClient())
        paymentContext =  STPPaymentContext(customerContext: customerContext!, configuration: config, theme: .defaultTheme)
        paymentContext?.retryLoading()
        self.paymentContext?.delegate = self
        self.paymentContext?.hostViewController = self
        self.paymentContext?.paymentAmount = 5000 // This is in cents, i.e. $50 USD
    }

    @IBAction func createNewCustomer(_ sender: UIButton) {
        ApiClient.createCustomer()
    }
    
    @IBAction func payNowAction(_ sender: UIButton) {
        self.paymentContext?.presentPaymentOptionsViewController()
    }
}


extension ViewController: STPPaymentContextDelegate {
    
    // When the user selects a new payment method or enters shipping information.
    func paymentContextDidChange(_ paymentContext: STPPaymentContext) {
       
        // If you prefer a modal presentation
        if paymentContext.selectedPaymentOption != nil && isSetShipping{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                paymentContext.presentShippingViewController()
            }
        }
        
        // When your user is ready to pay (e.g., they tap the Buy button) call requestPayment on your payment context.
        if paymentContext.selectedShippingMethod != nil && !isSetShipping {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
             self.paymentContext?.requestPayment()
            }
        }
    }
    
    // This method is called after your user enters a shipping address. Validate the returned address and determine the shipping methods available for that address.
    func paymentContext(_ paymentContext: STPPaymentContext, didUpdateShippingAddress address: STPAddress, completion: @escaping STPShippingMethodsCompletionBlock) {
        isSetShipping = false
        
        // PKShippingMethod defines a shipping method for delivering physical goods.
        let upsGround = PKShippingMethod()
        upsGround.amount = 0
        upsGround.label = "UPS Ground"
        upsGround.detail = "Arrives in 3-5 days"
        upsGround.identifier = "ups_ground"
        
        let fedEx = PKShippingMethod()
        fedEx.amount = 5.99
        fedEx.label = "FedEx"
        fedEx.detail = "Arrives tomorrow"
        fedEx.identifier = "fedex"
        
        if address.country == "US" {
            completion(.valid, nil, [upsGround, fedEx], upsGround)
        }
        else {
            completion(.invalid, nil, nil, nil)
        }
    }

    // This method is called in the rare case that the payment context’s initial loading call fails, usually due to lack of internet connectivity.
    func paymentContext(_ paymentContext: STPPaymentContext, didFailToLoadWithError error: Error) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // This method is called when the customer has successfully selected a payment method. Submit the payment to Stripe using a Payment Intent. Stripe uses this payment object to track and handle all the states of the payment until the payment completes.
    func paymentContext(_ paymentContext: STPPaymentContext, didCreatePaymentResult paymentResult: STPPaymentResult, completion: @escaping STPPaymentStatusBlock) {
        
        ApiClient.createPaymentIntent(amount: (Double(paymentContext.paymentAmount+Int(truncating: (paymentContext.selectedShippingMethod?.amount)!))), currency: "usd",customerId: "cus_KcOG0I40A30WqD") { (response) in
            switch response {
            case .success(let clientSecret):
                // Assemble the PaymentIntent parameters
                let paymentIntentParams = STPPaymentIntentParams(clientSecret: clientSecret)
                paymentIntentParams.paymentMethodId = paymentResult.paymentMethod?.stripeId
                paymentIntentParams.paymentMethodParams = paymentResult.paymentMethodParams
                
                STPPaymentHandler.shared().confirmPayment(paymentIntentParams, with: paymentContext) { status, paymentIntent, error in
                    switch status {
                    case .succeeded:
                        // Your backend asynchronously fulfills the customer's order, e.g. via webhook
                        completion(.success, nil)
                    case .failed:
                        completion(.error, error) // Report error
                    case .canceled:
                        completion(.userCancellation, nil) // Customer cancelled
                    @unknown default:
                        completion(.error, nil)
                    }
                }
            case .failure(let error):
                completion(.error, error) // Report error from your API
                break
            }
        }
        
    }
    
    // This method is called after the previous method, when any auxiliary UI that has been displayed (such as the Apple Pay dialog) has been dismissed. You should inspect the returned status and show an appropriate message to your user.
    func paymentContext(_ paymentContext: STPPaymentContext, didFinishWith status: STPPaymentStatus, error: Error?) {
        switch status {
           case .error:
              //self.showError(error)
                print("didFinishWith error")
           case .success:
              // self.showReceipt()
                print("didFinishWith success")
           case .userCancellation:
               return // Do nothing
           }
    }
}
