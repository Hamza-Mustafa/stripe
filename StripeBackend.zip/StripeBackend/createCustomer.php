
<?php


require_once('./stripe-php/init.php');
\Stripe\Stripe::setApiKey('sk_test_51JwPp2Eb3oAoI2qJREXAHY0K4TgVS67pKn0j12xjreMDibxIPYoE6AbNiScMKCnYg9NegwOYaClKRPtKCg0CB4ym00GDgNnPBT');


$email =  $_POST['email'] ;
$fullName = $_POST['name'];
$phone	= $_POST['phone'];

$key = \Stripe\Customer::create([
  'description' => 'testing','email'=>"$email",'phone'=>"$phone", 'name'=>$fullName
]);


echo json_encode($key);

?>
